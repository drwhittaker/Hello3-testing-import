# trying again
# hello2
# relearning 
print("...and off we go...")
dog = 'cat'
for n in dog:
  print(n)
print("tried again")
print("wonder if this will ever amount to anything more than a hobby?")
